USE auxiliary;
DROP TABLE holidays;
DROP TABLE school_breaks;

USE master;

DROP DATABASE auxiliary;

GO
