USE auxiliary;

--1980
INSERT INTO dbo.wakacje VALUES('1980-01-21','1980-02-24','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1980-06-28','1980-08-31','Letnie wakacje');

--1981
INSERT INTO dbo.wakacje VALUES('1981-01-19','1981-02-22','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1981-06-27','1981-08-31','Letnie wakacje');

--1982
INSERT INTO dbo.wakacje VALUES('1982-01-18','1982-02-21','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1982-06-26','1982-08-31','Letnie wakacje');

--1983
INSERT INTO dbo.wakacje VALUES('1983-01-17','1983-02-20','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1983-06-25','1983-08-31','Letnie wakacje');

--1984
INSERT INTO dbo.wakacje VALUES('1984-01-16','1984-02-19','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1984-06-30','1984-09-02','Letnie wakacje');

--1985
INSERT INTO dbo.wakacje VALUES('1985-01-21','1985-02-24','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1985-06-29','1985-09-01','Letnie wakacje');

--1986
INSERT INTO dbo.wakacje VALUES('1986-01-20','1986-02-23','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1986-06-28','1986-08-31','Letnie wakacje');

--1987
INSERT INTO dbo.wakacje VALUES('1987-01-19','1987-02-22','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1987-06-27','1987-08-31','Letnie wakacje');

--1988
INSERT INTO dbo.wakacje VALUES('1988-01-18','1988-02-21','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1988-06-25','1988-08-31','Letnie wakacje');

--1989
INSERT INTO dbo.wakacje VALUES('1989-01-16','1989-02-19','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1989-06-24','1989-08-31','Letnie wakacje');

--1990
INSERT INTO dbo.wakacje VALUES('1990-01-15','1990-02-18','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1990-06-30','1990-09-02','Letnie wakacje');

--1991
INSERT INTO dbo.wakacje VALUES('1991-01-21','1991-02-24','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1991-06-29','1991-09-01','Letnie wakacje');

--1992
INSERT INTO dbo.wakacje VALUES('1992-01-20','1992-02-23','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1992-06-27','1992-08-31','Letnie wakacje');

--1993
INSERT INTO dbo.wakacje VALUES('1993-01-18','1993-02-21','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1993-06-26','1993-08-31','Letnie wakacje');

--1994
INSERT INTO dbo.wakacje VALUES('1994-01-17','1994-02-20','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1994-06-25','1994-08-31','Letnie wakacje');

--1995
INSERT INTO dbo.wakacje VALUES('1995-01-16','1995-02-19','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1995-07-01','1995-08-31','Letnie wakacje');

--1996
INSERT INTO dbo.wakacje VALUES('1996-01-15','1996-02-18','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1996-06-29','1996-09-01','Letnie wakacje');

--1997
INSERT INTO dbo.wakacje VALUES('1997-01-20','1997-02-23','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1997-06-28','1997-08-31','Letnie wakacje');

--1998
INSERT INTO dbo.wakacje VALUES('1998-01-19','1998-02-22','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1998-06-27','1998-08-31','Letnie wakacje');

--1999
INSERT INTO dbo.wakacje VALUES('1999-01-18','1999-02-21','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('1999-06-26','1999-08-31','Letnie wakacje');

--2000
INSERT INTO dbo.wakacje VALUES('2000-01-17','2000-02-20','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2000-07-01','2000-08-31','Letnie wakacje');

--2001
INSERT INTO dbo.wakacje VALUES('2001-01-15','2001-02-18','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2001-06-30','2001-09-02','Letnie wakacje');

--2002
INSERT INTO dbo.wakacje VALUES('2002-01-21','2002-02-24','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2002-06-29','2002-09-01','Letnie wakacje');

--2003
INSERT INTO dbo.wakacje VALUES('2003-01-20','2003-02-23','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2003-06-28','2003-08-31','Letnie wakacje');

--2004
INSERT INTO dbo.wakacje VALUES('2004-01-19','2004-02-22','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2004-06-26','2004-08-31','Letnie wakacje');

--2005
INSERT INTO dbo.wakacje VALUES('2005-01-17','2005-02-20','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2005-06-25','2005-08-31','Letnie wakacje');

--2006
INSERT INTO dbo.wakacje VALUES('2006-01-16','2006-02-19','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2006-07-01','2006-08-31','Letnie wakacje');

--2007
INSERT INTO dbo.wakacje VALUES('2007-01-15','2007-02-18','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2007-06-30','2007-09-02','Letnie wakacje');

--2008
INSERT INTO dbo.wakacje VALUES('2008-01-21','2008-02-24','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2008-06-28','2008-08-31','Letnie wakacje');

--2009
INSERT INTO dbo.wakacje VALUES('2009-01-19','2009-02-22','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2009-06-27','2009-08-31','Letnie wakacje');

--2010
INSERT INTO dbo.wakacje VALUES('2010-01-18','2010-02-21','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2010-06-26','2010-08-31','Letnie wakacje');

--2011
INSERT INTO dbo.wakacje VALUES('2011-01-17','2011-02-20','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2011-06-25','2011-08-31','Letnie wakacje');

--2012
INSERT INTO dbo.wakacje VALUES('2012-01-16','2012-02-19','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2012-06-30','2012-09-02','Letnie wakacje');

--2013
INSERT INTO dbo.wakacje VALUES('2013-01-21','2013-02-24','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2013-06-29','2013-09-01','Letnie wakacje');

--2014
INSERT INTO dbo.wakacje VALUES('2014-01-20','2014-02-23','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2014-06-28','2014-08-31','Letnie wakacje');

--2015
INSERT INTO dbo.wakacje VALUES('2015-01-19','2015-02-22','Ferie zimowe');
INSERT INTO dbo.wakacje VALUES('2015-06-27','2015-08-31','Letnie wakacje');

GO
USE master;