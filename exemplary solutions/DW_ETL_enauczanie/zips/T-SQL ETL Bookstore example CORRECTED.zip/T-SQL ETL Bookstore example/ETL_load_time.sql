use DW_bookstore_test
go

insert into dbo.DimTime("Hour", "TimeOfDay") values (0, 'od 0 do 8');
insert into dbo.DimTime("Hour", "TimeOfDay") values (1, 'od 0 do 8');
insert into dbo.DimTime("Hour", "TimeOfDay") values (2, 'od 0 do 8');
insert into dbo.DimTime("Hour", "TimeOfDay") values (3, 'od 0 do 8');
insert into dbo.DimTime("Hour", "TimeOfDay") values (4, 'od 0 do 8');
insert into dbo.DimTime("Hour", "TimeOfDay") values (5, 'od 0 do 8');
insert into dbo.DimTime("Hour", "TimeOfDay") values (6, 'od 0 do 8');
insert into dbo.DimTime("Hour", "TimeOfDay") values (7, 'od 0 do 8');
insert into dbo.DimTime("Hour", "TimeOfDay") values (8, 'od 0 do 8');
insert into dbo.DimTime("Hour", "TimeOfDay") values (9, 'od 9 do 12');
insert into dbo.DimTime("Hour", "TimeOfDay") values (10, 'od 9 do 12');
insert into dbo.DimTime("Hour", "TimeOfDay") values (11, 'od 9 do 12');
insert into dbo.DimTime("Hour", "TimeOfDay") values (12, 'od 9 do 12');
insert into dbo.DimTime("Hour", "TimeOfDay") values (13, 'od 13 do 15');
insert into dbo.DimTime("Hour", "TimeOfDay") values (14, 'od 13 do 15');
insert into dbo.DimTime("Hour", "TimeOfDay") values (15, 'od 13 do 15');
insert into dbo.DimTime("Hour", "TimeOfDay") values (16, 'od 16 do 20');
insert into dbo.DimTime("Hour", "TimeOfDay") values (17, 'od 16 do 20');
insert into dbo.DimTime("Hour", "TimeOfDay") values (18, 'od 16 do 20');
insert into dbo.DimTime("Hour", "TimeOfDay") values (19, 'od 16 do 20');
insert into dbo.DimTime("Hour", "TimeOfDay") values (20, 'od 16 do 20');
insert into dbo.DimTime("Hour", "TimeOfDay") values (21, 'od 21 do 23');
insert into dbo.DimTime("Hour", "TimeOfDay") values (22, 'od 21 do 23');
insert into dbo.DimTime("Hour", "TimeOfDay") values (23, 'od 21 do 23');
