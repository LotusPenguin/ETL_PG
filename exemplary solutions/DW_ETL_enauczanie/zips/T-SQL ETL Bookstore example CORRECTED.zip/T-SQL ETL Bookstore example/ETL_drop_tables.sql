USE DW_bookstore_test
go

DROP TABLE Autorstwo;
DROP TABLE Sprzedaz_ksiazki;
DROP TABLE Sprzedawca;
DROP TABLE Ksiegarnia;
DROP TABLE Ksiazka;
DROP TABLE Autor;